package app;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.regex.Pattern;

public class App {
    public static void main(String[] args) {
        boolean sortir = false;
        String[][] GuardarNoms = new String[12][3];
        while (!sortir) {
            System.out.println("-----------------------------------------");
            System.out.println("            Joc de l'usuari               ");
            System.out.println("-----------------------------------------");
            
            int opcio = Integer.parseInt(System.console().readLine(" 1- afagir usuari \n 2- Loging \n 3- sortir \n Tria una opcio: "));

            switch (opcio) {
            case 1:
                System.out.println("1- afagir usuari ");
                CrearUsuari(GuardarNoms);
                break;
            case 2:
                System.out.println(" 2- Loging ");
                loging(GuardarNoms);
                break;
            case 3:
                System.out.println(" 3- sortir");
                sortir = true;
                break;
            }

        }
    }

    public static void CrearUsuari(String[][] GuardarNoms) {
        int l = 0;
        boolean intruduir = false;
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String[] datavui = sdf.format(date).split("/");
        while (!intruduir) {
            String nom = System.console().readLine(" intrudueix un nom: ");
            String cognom = System.console().readLine(" intrudueix un cognom: ");
            String adreça = System.console().readLine(" intrudueix un adreça: ");
            String poblacio = System.console().readLine(" intrudueix un poblacio: ");
            boolean cargar = false;
            while (!cargar) {
                String usuari = System.console().readLine("escriu un usuari: ");
                boolean a = false;
                String password = "";
                while (!a) {
                    password = System.console().readLine("escriu una contrasenya 8 caracters minim : ");
                    if (password.matches("[a-z]*[A-Z]*[0-9]*{8,}")) {
                        System.out.println("contrasenya es valida ");
                        a = true;
                        cargar = true;
                    } else {
                        System.out.println("contrasenya es incorrecta ");
                    }
                }
                for (int j = 0; j < GuardarNoms[0].length; j++) {

                    GuardarNoms[0][j] = usuari;
                    GuardarNoms[1][j] = nom;
                    GuardarNoms[2][j] = cognom;
                    GuardarNoms[3][j] = adreça;
                    GuardarNoms[4][j] = poblacio;
                    GuardarNoms[5][j] = password;
                    l = j;
                }

                intruduir = true;
            }
            System.out.println("--------------------------------------------------------------------------");
            System.out.println("                                  dades del usuari                        ");
            System.out.println("--------------------------------------------------------------------------");
            System.out.println(" noms: " + GuardarNoms[1][l] + " \n cognom: " + GuardarNoms[2][l] + "\n adreça: "
                    + GuardarNoms[3][l] + " \n poblacio: " + GuardarNoms[4][l] + "\n usuari: " + GuardarNoms[0][l]
                    + "\n contrassenya: " + GuardarNoms[5][l]);
            System.out.println(" Date: " + datavui[0] + "/" + datavui[1] + "/" + datavui[2]);
            System.out.println("--------------------------------------------------------------------------");

           

        }
    }

    public static void loging(String[][] GuardarNoms) {
        String usuari = " ";
        String contrassenya = " ";
        int l = 0;
        boolean repetit = false;
        
        for (int i = 0; i < GuardarNoms[0].length-1; i++) {
            for (int j = i+1; j < GuardarNoms[0].length; j++) {
                if(GuardarNoms[i][1].compareToIgnoreCase(GuardarNoms[j][1])>0){
                    String ordenar = GuardarNoms[i][1];
                    GuardarNoms[i][1]=GuardarNoms[j][1];
                    GuardarNoms[j][1]= ordenar;
                }
            }
            
        }
        boolean y = false;
       
        String Buscar = System.console().readLine(" vols buscar un usuari? si/no ");
        if(buscar.equals("si") ||buscar.equals("s")){
            while(!y){
                for (int i = 0; i < GuardarNoms[0].length; i++) {
                    String BuscarUsuari = System.console().readLine(" posa un usuari: ");
                    if(BuscarUsuari==GuardarNoms[i][1]){
                        System.out.println(" usuari existeix ");
                        y=true;
                        break;
                    }
                    else{
                        System.out.println(" usuari no existeix \n Provau de nou");
                    }
                }
    
            }
        }
        
       
        while (!repetit) {
            usuari = System.console().readLine("USUARI: ");
            contrassenya = System.console().readLine("PASSWORD: ");
            for (int i = 0; i < GuardarNoms[0].length; i++) {
                l = i;
            }
            if (usuari.equalsIgnoreCase(GuardarNoms[0][l]) && contrassenya.equalsIgnoreCase(GuardarNoms[5][l])) {

                
                System.out.println("                          Benvinguts el club                              ");
                System.out.println("--------------------------------------------------------------------------");
                System.out.println("                           dades del usuari                                ");
                System.out.println("---------------------------------------------------------------------------------");
                System.out.println(" noms: " + GuardarNoms[1][l] + " \n cognom: " + GuardarNoms[2][l] + "\n adreça: "
                        + GuardarNoms[3][l] + " \n poblacio: " + GuardarNoms[4][l] + "\n usuari: " + GuardarNoms[0][l]
                        + "\n contrassenya: " + GuardarNoms[5][l]);
                System.out.println("----------------------------------------------------------------------------------");
                repetit = true;
            } else {
                System.out.println("contrassenya o usuari incorrecta");
                System.out.println("Provau de nou");
            }
        }

    }

}