/**
 * ex_4
 */
import java.util.Random;
public class ex_4 {

    public static void main(String[] args) {
        
        int [] array = new int [1000];
        Random rnd = new Random(6);
         for(int i = 0;i<array.length;i++)
         {
            
         }
    }
}